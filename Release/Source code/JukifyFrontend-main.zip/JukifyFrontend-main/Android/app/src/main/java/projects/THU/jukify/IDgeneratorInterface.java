package projects.THU.jukify;

interface IDgeneratorInterface {
    /**
     * Getsr random string for given length
     * @param length Length of the string
     * @return User ID String
     */
    public static String getBase62(int length){ return null; };
}
