import unittest
import sys
from server import app
import json

class TestServer(unittest.TestCase):
    authToken = "invalid"
    partyId=""
    #Successful party creation
    def testCreateParty(self):
        tester = app.test_client(self)

        payload = json.dumps({
            "userId": "test",
            "authToken": self.authToken
        })

        result = tester.post('/createParty',headers={"Content-Type": "application/json"}, data=payload)
        self.assertEqual(200, result.status_code)
        self.assertIn("Success", result.json['response'])
        self.partyId=result.json['partId']

    def testCloseParty(self):
        tester = app.test_client(self)

        payload = json.dumps({
            "userId": "test",
            "partyId": self.partyId
        })

        result = tester.post('/closeParty',headers={"Content-Type": "application/json"}, data=payload)
        self.assertEqual(200, result.status_code)
        self.assertIn("Success", result.json['response'])        



if __name__ == "__main__":
    if len(sys.argv) > 1:
        TestServer.authToken = sys.argv.pop()        
    unittest.main()