from flask import Flask, render_template, request, jsonify
import random
import classes
import json
import sys
import spotipy
import database

app = Flask(__name__)

parties = {}

myDb = database.Database()


# Use postman to send request to http://127.0.0.1:5000/createparty with body in JSON:
#{
#    "userId": "1",
#    "authToken": "ASLDKfmasldkmfaskme2131re3dq3"
#    "playlistId" : "37i9dQZF1DXbKGrOUA30KN"
#}
@app.route('/createParty', methods =['POST'])
def createParty():
    # get POST content
    masterId = request.get_json()['userId']
    authKey = request.get_json()['authToken']
    playlistId = request.get_json()['playlistId']

    #if token is invalid, dont create party
    try:
        spotify = spotipy.Spotify(auth=authKey)        
        spotify.start_playback(context_uri='spotify:playlist:'+playlistId)

        #not in use for now
        #meResult = spotify.me()
        #spUserId = meResult['id']
        
        # Create spotify playlist usable as a queue till the party exists
        #createCustomQueue = spotify.user_playlist_create(spUserId, "tempQueue", public=True, collaborative=False, description='Temp playlist for Jukify')
        #results = spotify.current_user_recently_played(limit=10) 
    except:
        return jsonify( response = "Failure: Access token expired or there is no active device", requestId="0")

    # generate party id
    partyId = random.randint(10000,99999)
    while myDb.isPartyIdExist(partyId):
        partyId = random.randint(10000,99999)      
    #we might use hash str in future
    partyId=str(partyId)  
    # create party instance
    newParty = classes.Party(partyId, masterId, authKey)
    # save party instance
    parties[newParty.id] = newParty    
    myDb.saveParty(newParty.id,masterId)
    

    # #get songs for response
    # items = results['items']
    # songs=[]
    # if len(items) > 0:
    #     for i,item in enumerate(items):
    #         song=classes.Song(item['track']['id'],item['track']['name'],item['track']['album']['name'],item['track']['artists'][0]['name'])
    #         songs.append(json.dumps(song.__dict__))
    
    return jsonify( response="Success", userId = masterId, partyId = newParty.id, requestId="0")


# Use postman to send request to http://127.0.0.1:5000/closeparty with body in JSON:
#{
#    "userId": "12e11",
#    "partyId": "3781"
#}
@app.route('/closeParty', methods = ['POST'])
def closeParty():
    # get POST data
    postData = request.get_json()
    masterId = postData['userId']
    partyId = postData['partyId']

    #check if thats master who wants to close party
    if(partyId in parties):            
        if parties[partyId].masterId == masterId:
            myDb.setClosingDate(partyId)
            del parties[partyId]            
            return jsonify( response = "Success: PARTY IS DELETED" , requestId="1")
        else:
            return jsonify ( response = "Failure: PARTY ID MATCHED, BUT MASTER ID DOES NOT MATCH ", requestId="1")
    #return jsonify( masterId = masterId, partyId = str(newParty.getId()))
    else:
        return jsonify( response = "Failure: PARTY ID DOES NOT MATCH" , requestId="1")
    



#{
#    "userId": "1",
#    "partyId": "3781"
#}
@app.route('/join', methods = ['POST'])
def join():
    # get POST data
    postData = request.get_json()
    userId = postData['userId']
    partyId = postData['partyId']
    # check if party exists
    if partyId not in parties:
        return jsonify( response = "Failure: BAD PARTY ID" , requestId="2")

    if parties[partyId].join(userId):
        #maybe return current song
        spotify = spotipy.Spotify(auth=parties[partyId].authKey)
        results = spotify.currently_playing(market='DE')   
        if(results is None):
            return jsonify( response = "Success: JOINED", partyId = partyId, userId = userId, currentMs = "0", song="No Playback", requestId="2") 
        item = results['item']
        currentMs = str(results['progress_ms'])
        durationMs = str(item['duration_ms'])
        song=classes.Song(item['id'],item['name'],item['album']['name'],item['artists'][0]['name'])

        return jsonify( response = "Success: JOINED", partyId = partyId, userId = userId, currentMs = currentMs, durationMs=durationMs, song=json.dumps(song.__dict__), requestId="2") 
    else:
        return jsonify( response = "Failure: COULD NOT JOIN THE PARTY", requestId="2")

#{
#    "userId": "1",
#    "partyId": "3781"
#}
@app.route('/leave', methods = ['POST'])
def leave():
    # get POST data
    postData = request.get_json()
    userId = postData['userId']
    partyId = postData['partyId']
    # check if party exists
    if partyId not in parties:
        return jsonify( response = "Failure: BAD PARTY ID" , requestId="3")

    if parties[partyId].leave(userId):
        #print(parties[partyId].member, file=sys.stdout) 
        return jsonify( response = "Success: LEFT", partyId = partyId, userId = userId, requestId="3") 
    else:
        return jsonify( response = "Failure: COULD NOT LEAVE THE PARTY", requestId="3")


# Use postman to send request to http://127.0.0.1:5000/playSong with body in JSON:
#{    
#    "partyId": "3781"
#    "songId" : "232mk3v32K2r3R"
#}
@app.route('/playSong', methods = ['POST'])
def playSong():
    # get POST data
    postData = request.get_json()
    
    songId = postData['songId']
    partyId = postData['partyId']
    
    # check if party exists
    if(partyId in parties):       
        spotify = spotipy.Spotify(auth=parties[partyId].authKey) 
        try:
            spotify.start_playback(uris=['spotify:track:4cOdK2wGLETKBW3PvgPWqT'])
            #(uris=['spotify:track:'+songId])  
        except:
            return jsonify(response = "Failure: Song could not be played.", requestId="4")
        
        item = spotify.track(songId, market='DE')        
        song = classes.Song(item['id'], item['name'], item['album']['name'], item['artists'][0]['name'])      
        myDb.saveSong(partyId, song)
        return jsonify(response = "Success: Song is being played", requestId="4")
    else:     
        return jsonify( response = "Failure: BAD PARTY ID" , requestId="4")
    
# Use postman to send request to http://127.0.0.1:5000/searchSong with body in JSON:
#{    
#    "partyId": 3781
#    "searchWord" : "Never gonna let you down"
#}
#returns jsonArray
@app.route('/searchSong', methods = ['POST'])
def searchSong():
    # get POST data
    postData = request.get_json()
    
    searchWord = postData['searchWord']
    partyId = postData['partyId']
    
    # check if party exists
    if(partyId in parties):       
        spotify = spotipy.Spotify(auth=parties[partyId].authKey) 
        results=spotify.search(q=searchWord, limit=5, market='DE')        
        items = results['tracks']['items']
        songs=[]
        if len(items) > 0:
            for i,item in enumerate(items):
                song=classes.Song(item['id'],item['name'],item['album']['name'],item['artists'][0]['name'])
                #songs[i]=json.dumps(song.__dict__)
                songs.append(json.dumps(song.__dict__))       
            return jsonify( response= "Success: Lists of songs returned", songs=songs, requestId="5")
        else:
            return jsonify(response = "Failure: No songs found", requestId="5")
    else:        
        return jsonify( response = "Failure: BAD PARTY ID" , requestId="5")        


# Use postman to send request to http://127.0.0.1:5000/getPartyHistory with body in JSON:
#{    
#    "partyId": 3781
# }

#returns jsonArray
@app.route('/getPartyHistory', methods = ['POST'])
def getPartyHistory():
    # get POST data
    postData = request.get_json()
    partyId = postData['partyId']
    
    # LIMITATION to use this functionality !
    # we can only view the party history if a party already took place and finished.
    # we cannot see any party history detail if party is not over yet.
    # To see if it is over, we check if there is an existing "closing date entry" in the database
    # If closing date entry is not Null ( this is doublechecked by isPartyClosed function in database.py), then we proceed.

    if(myDb.isPartyClosed(partyId)):     # if party is closed, only then we can see results  
        results = myDb.getSongs(partyId)
        songs=[]  
        if len(results) > 0:
            for i,item in enumerate(results):
                song=classes.Song(item[0],item[1],item[2],item[3])
                songs.append(json.dumps(song.__dict__))
            return jsonify(response = "Success: Songs that are played during the party (ID) " + partyId, songs=songs, requestId="6") 
        else:
            return jsonify(response = "Failure: No songs were played during this party ", requestId="6")        
    else:     
        return jsonify(response = "Failure: Party History cannot be viewed ( party does not exist or bad ID)", requestId="6")    


@app.route('/getPlaylists', methods = ['POST'])
def playlists():
    # get POST content
    postData = request.get_json()
    authKey = request.get_json()['authToken']
    #connect to spotify
    spotify = spotipy.Spotify(auth=authKey) 

    #get user spotify playlists
    try:
        userPlaylists = spotify.current_user_playlists(limit=30, offset=0)
    except:
        #in case authtoken is invalid
        return jsonify(response="Failure", requestId="7")

    playlistCount = userPlaylists['total']
    returnList=[]
    if playlistCount <= 5:
        featuredPlaylists = spotify.featured_playlists(locale=None, country=None, timestamp=None, limit=30-playlistCount, offset=0)
        ### Adding user playlist if exists
        playlistItems = userPlaylists['items']
        for i,item in enumerate(playlistItems):  
            playlist={}
            playlist['imageUrl'] = item['images'][0]['url']
            playlist['playlistName'] = item['name']
            playlist['playlistId'] = item['id']
            playlist['numberOfSongs'] = item['tracks']['total']
            returnList.append(playlist)

        ### Parsing featured playlists
        playlistItems = featuredPlaylists['playlists']['items']
        for i,item in enumerate(playlistItems):  
            playlist={}
            playlist['imageUrl'] = item['images'][0]['url']
            playlist['playlistName'] = item['name']
            playlist['playlistId'] = item['id']
            playlist['numberOfSongs'] = item['tracks']['total']
            returnList.append(playlist)
        return jsonify(response="Success: Playlists returned", playlists=returnList, requestId="7")

    else:
        playlistItems = userPlaylists['items']
        for i,item in enumerate(playlistItems):  
            playlist={}
            if(item['tracks']['total'] != 0):
                playlist['imageUrl'] = item['images'][0]['url']
                playlist['playlistName'] = item['name']
                playlist['playlistId'] = item['id']
                playlist['numberOfSongs'] = item['tracks']['total']
                returnList.append(playlist)
        return jsonify(response="Success: Playlists returned", playlists=returnList, requestId="7")
    



#{
#    "partyId": "21324",
#    "authToken": "3781"
#}
@app.route('/updateToken', methods = ['POST'])
def updateToken():
    # get POST data
    postData = request.get_json()
    newToken = postData['authToken']
    partyId = postData['partyId']
    # check if party exists
    if partyId not in parties:
        return jsonify( response = "Failure: BAD PARTY ID", requestId="8" )   
    else:
        parties[partyId].authKey = newToken
        return jsonify( response = "Success: Spotify token is updated.", requestId="8")


# @app.route('/getQueuePlaylist', methods = ['POST'])
# def playlists():
#     # get POST content
#     postData = request.get_json()
#     authKey = request.get_json()['authToken']
#     #connect to spotify
#     spotify = spotipy.Spotify(auth=authKey) 
#     playlistItems = playlist_tracks(playlist_id, fields=None, limit=100, offset=0, market=None)

#     return jsonify(response="success", playlists=playlistItems)



if __name__ == '__main__':
    app.run(debug=True)
