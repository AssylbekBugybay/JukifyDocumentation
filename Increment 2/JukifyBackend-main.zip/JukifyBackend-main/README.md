# Jukify Backend Repository


# DO NOT WORK/PUSH ON MAIN!!!!
# WORK IN YOUR OWN BRANCHES
How to:

mkdir jukify

cd ./jukify

git clone https://github.com/roflije/JukifyBackend/

cd ./JukifyBackend

git checkout -b myname


How to sync with main after merging branch commits:
git pull origin main


How to run unittest:

py unittest_server.py "BQAcbK3uqjoUzUiTp6i4cKmzUjrllUaNyEyRkG1Agcroa0mcgVvKM9RZ7fLhMLKNmt4_Khs7F2-2oUctvITEhN-02-ceuFwjtPxYVbKh8JW2ELD6Fn8p7hZZTQTN2DPsvO4ytE31DQ4EMTe9asMkpR0xFidmiwZ3L0Gq1X4e1NsTWa-6bNhe-j2Zi29qH40pCS0"
you should give spotify token as an argument