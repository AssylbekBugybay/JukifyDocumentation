import mysql.connector
from datetime import datetime

class Database:
    def __init__(self):
        #self.host="sql11.freemysqlhosting.net",
        #self.user="sql11448170",
        #self.password="Y8lrQ9Uxux",
        #self.database="sql11448170"
        self.config = {
            'host' : "87.106.171.240",
            'user' : "jukify",
            'password' : "SWProject2021",
            'database' : "jukifydb"
        }
    def saveParty(self, partyId, masterId):
        now = datetime.now()
        creationDate = now.strftime('%Y-%m-%d %H:%M:%S')
        cnx=mysql.connector.connect(**self.config)
        myCursor = cnx.cursor()
        cmd="INSERT INTO Party values(%s,%s,%s,null);"
        values=(partyId, creationDate, masterId)        
        myCursor.execute(cmd,values)
        cnx.commit()
        myCursor.close()        
        cnx.close()

    def getParties(self):
        cnx=mysql.connector.connect(**self.config)
        myCursor = cnx.cursor()
        cmd="SELECT * FROM Party;"
        myCursor.execute(cmd)
        results=myCursor.fetchall()
        myCursor.close()
        cnx.close()
        return results

    def saveSong(self, partyId, song):
        cnx=mysql.connector.connect(**self.config)
        myCursor = cnx.cursor()
        cmd="INSERT INTO Songs values(%s,%s,%s,%s,%s);"
        values=(song.spotifyId, song.name, song.album, song.artist, partyId)        
        myCursor.execute(cmd,values)
        myCursor.close()
        cnx.commit()
        cnx.close()
    
    def getSongs(self, partyId):
        cnx=mysql.connector.connect(**self.config)
        myCursor = cnx.cursor()
        cmd="SELECT * FROM Songs WHERE Party_idParty="+partyId+";"        
        myCursor.execute(cmd)
        results=myCursor.fetchall()
        myCursor.close()
        cnx.close()
        return results

    def isPartyIdExist(self, newPartyId):
        cnx=mysql.connector.connect(**self.config)
        myCursor = cnx.cursor()
        cmd="SELECT * FROM Party WHERE idParty="+str(newPartyId)+";"
        myCursor.execute(cmd)
        results=myCursor.fetchall()
        myCursor.close()
        cnx.close()
        if(len(results)>0):
            return True
        else:
            return False

    def setClosingDate(self, partyId):
        now = datetime.now()
        closingDate = now.strftime('%Y-%m-%d %H:%M:%S')
        cnx=mysql.connector.connect(**self.config)
        myCursor = cnx.cursor()
        query="UPDATE Party SET closingDate=%s WHERE idParty = %s"
        values=(closingDate, partyId)        
        myCursor.execute(query, values)
        cnx.commit()
        myCursor.close()        
        cnx.close()

    def isPartyClosed(self, partyId):
        cnx=mysql.connector.connect(**self.config)
        myCursor = cnx.cursor()
        cmd="SELECT * FROM Party WHERE idParty="+partyId+ " AND closingDate IS NOT NULL;"
        # then there is a closing date for a party ( then one can view history)
        myCursor.execute(cmd)
        results=myCursor.fetchall()
        myCursor.close()
        cnx.close()
        if(len(results)>0):
            return True
        else:
            return False


#db = Database()
#if (db.isPartyClosed(str(30891))):
#    print ("party closed")
#else:
#    print ("NULL -- party is not closed ")