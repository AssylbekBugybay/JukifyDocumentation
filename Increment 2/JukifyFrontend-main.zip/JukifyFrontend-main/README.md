# Jukify Frontend Repository


# DO NOT WORK/PUSH ON MAIN!!!!
# WORK IN YOUR OWN BRANCHES
How to:

mkdir jukify

cd ./jukify

git clone https://github.com/roflije/JukifyFrontend/

cd ./JukifyFrontend

git checkout -b myname


# If any trouble with repo cloning due to filename too long

Run as administrator the following command: git config --system core.longpaths true
