package projects.THU.jukify;

import com.journeyapps.barcodescanner.CaptureActivity;

public class ScanCode extends CaptureActivity {

}
