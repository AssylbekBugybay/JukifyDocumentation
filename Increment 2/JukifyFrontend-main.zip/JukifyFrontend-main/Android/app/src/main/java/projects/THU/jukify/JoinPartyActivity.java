package projects.THU.jukify;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class JoinPartyActivity extends AppCompatActivity {

    FloatingActionButton qrButton;
    QrScanner qrClass;
    BottomNavigationView navigationView;
    EditText partyText;
    Button join;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_party);

        partyText = findViewById(R.id.editTextTextPersonName);
        join = findViewById(R.id.button_sendCode);
        //Bottom Navigation bar
        qrButton = findViewById(R.id.button_useQRCodeJoinParty);
        navigationView = findViewById(R.id.bottomNavigationView);
        navigationView.setBackground(null);
        navigationView.setSelectedItemId(R.id.placeholder);
        navigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.action_home:
                    Intent intent_home = new Intent(JoinPartyActivity.this, MainActivity.class);
                    startActivity(intent_home);
                    break;
                case R.id.action_party:
                    Intent intent_party = new Intent(JoinPartyActivity.this, PartyCreationActivity.class);
                    startActivity(intent_party);
                    break;
                case R.id.action_settings:
                    Intent intent_settings = new Intent(JoinPartyActivity.this, SettingsActivity.class);
                    startActivity(intent_settings);
                    break;
                case R.id.action_share:
                    break;
            }

            return false;
        });
        qrClass = new QrScanner(qrButton, this);

        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(JoinPartyActivity.this, PartyMemberActivity.class);
                intent.putExtra("partyName", partyText.getText().toString());
                startActivity(intent);
            }
        });
    }

    //Get the results of the qr scan
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null) {
            if(result.getContents() == null) {
                Log.e("Scan*******", "Cancelled scan");

            } else {
                Toast.makeText(this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this, PartyMemberActivity.class);
                intent.putExtra("partyName", result.getContents());
                startActivity(intent);
            }
        } else {
            // This is important, otherwise the result will not be passed to the fragment
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}