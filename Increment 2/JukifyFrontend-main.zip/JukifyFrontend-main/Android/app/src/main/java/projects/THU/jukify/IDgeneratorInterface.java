package projects.THU.jukify;

interface IDgeneratorInterface {
    public static String getBase62(int length){ return null; };
}
