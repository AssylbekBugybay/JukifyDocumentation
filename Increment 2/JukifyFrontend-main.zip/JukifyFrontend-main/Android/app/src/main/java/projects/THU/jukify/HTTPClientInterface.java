package projects.THU.jukify;

import android.content.Context;
import android.os.Handler;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.RequestQueue;

import org.json.JSONObject;

import java.util.HashMap;

interface HTTPClientInterface {
    public void setRequest(@Nullable Integer rt, @Nullable String p, @Nullable HashMap<String, String> b, @Nullable Handler h);
    public JSONObject getResponse();
    public static HTTPClient getInstance(Context c, int rt, String p, HashMap<String, String> b, Handler h){return null;};
    public static HTTPClient getInstance(){ return null; };
    public <T> void addToRequestQueue(Request<T> req);
    public void sendHTTP();

    }
