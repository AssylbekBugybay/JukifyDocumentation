package projects.THU.jukify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;

import java.util.HashMap;

public class PartyMasterActivity extends AppCompatActivity {
    private SharedPreferences.Editor editor;
    private SharedPreferences prefs;
    private String userID;
    private Intent intent;
    private String partyName;
    private TextView partyText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_party_master);


        intent = getIntent();
        partyName = intent.getStringExtra("partyName");
        partyText  = findViewById(R.id.masterPartyName);

        partyText.setText(partyName);



    }

    final private Handler handlerPlaySong = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(Message msg){
            System.out.println("Hello from response 2!");
        }
    };

    public void launchAddSongActivity(View view){
        prefs = getSharedPreferences("userpreference", Context.MODE_PRIVATE);
        editor = prefs.edit();

        HashMap<String,String> map = new HashMap<String,String>();
        map.put("songId","1");
        map.put("partyId",prefs.getString("partyId",""));
        System.out.println(prefs.getString("partyId",""));
        HTTPClient client = HTTPClient.getInstance(PartyMasterActivity.this, Request.Method.POST,"/playSong",map,handlerPlaySong);
        Thread t = new Thread(client);
        t.start();
    }

    /*
        Activity launcher area
     */
    public void launchAddSongActivity2(View view) {
        Intent intent = new Intent(this, AddSongActivity.class);
        startActivity(intent);
    }
}