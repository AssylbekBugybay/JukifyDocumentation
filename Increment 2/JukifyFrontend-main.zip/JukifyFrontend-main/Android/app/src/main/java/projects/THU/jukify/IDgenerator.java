package projects.THU.jukify;

import java.util.Random;

public class IDgenerator implements IDgeneratorInterface {

    private static char[] BASE62CHARS =
            "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
            .toCharArray();

    private static Random rand = new Random();



    public static String getBase62(int length)
    {

        StringBuilder sb = new StringBuilder(length);

        for (int i=0; i<length; ++i)
            sb.append(BASE62CHARS[rand.nextInt(62)]);

        return sb.toString();
    }
}
